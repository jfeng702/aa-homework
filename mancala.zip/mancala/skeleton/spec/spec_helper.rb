RSpec.configure do |config|
  config.color = true
end
